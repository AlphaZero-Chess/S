#!/bin/bash
echo "======================================"
echo "🎯 Sparky Final Verification Test"
echo "======================================"
echo ""

# Colors
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Test 1: Services Running
echo "📋 Test 1: Checking Services..."
python_running=$(sudo supervisorctl status python_service | grep RUNNING)
nextjs_running=$(sudo supervisorctl status nextjs | grep RUNNING)

if [ ! -z "$python_running" ]; then
    echo -e "${GREEN}✅ Python service is running${NC}"
else
    echo -e "${RED}❌ Python service is NOT running${NC}"
    exit 1
fi

if [ ! -z "$nextjs_running" ]; then
    echo -e "${GREEN}✅ Next.js service is running${NC}"
else
    echo -e "${RED}❌ Next.js service is NOT running${NC}"
    exit 1
fi

echo ""

# Test 2: Health Check
echo "📋 Test 2: Health Check..."
health_response=$(curl -s http://localhost:5000/health)
if echo "$health_response" | grep -q "healthy"; then
    echo -e "${GREEN}✅ Health check passed${NC}"
    echo "   Response: $health_response"
else
    echo -e "${RED}❌ Health check failed${NC}"
    exit 1
fi

echo ""

# Test 3: Streaming Test
echo "📋 Test 3: Testing Streaming (this will take ~5 seconds)..."
stream_response=$(timeout 10 curl -s -X POST http://localhost:5000/chat/stream \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Say hi"}],"systemPrompt":"Be brief"}')

if [ ! -z "$stream_response" ]; then
    word_count=$(echo "$stream_response" | wc -w)
    echo -e "${GREEN}✅ Streaming working${NC}"
    echo "   Words received: $word_count"
    echo "   Sample: ${stream_response:0:100}..."
else
    echo -e "${RED}❌ Streaming failed${NC}"
    exit 1
fi

echo ""

# Test 4: Next.js API
echo "📋 Test 4: Testing Next.js API..."
api_response=$(timeout 10 curl -s -X POST http://localhost:3000/api/chat \
  -H "Content-Type: application/json" \
  -d '{"messages":[{"role":"user","content":"Hi"}]}')

if [ ! -z "$api_response" ]; then
    echo -e "${GREEN}✅ Next.js API working${NC}"
    echo "   Response length: $(echo "$api_response" | wc -c) characters"
else
    echo -e "${RED}❌ Next.js API failed${NC}"
    exit 1
fi

echo ""
echo "======================================"
echo -e "${GREEN}🎉 All Tests Passed!${NC}"
echo "======================================"
echo ""
echo "📊 Summary:"
echo "   • Python Service: ✅ Running"
echo "   • Next.js Service: ✅ Running"
echo "   • Health Check: ✅ Passed"
echo "   • Streaming: ✅ Working"
echo "   • API Integration: ✅ Working"
echo ""
echo "🚀 Sparky is ready for production!"
echo ""
