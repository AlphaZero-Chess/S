'use client';

import { useState } from 'react';
import { ResizableHandle, ResizablePanel, ResizablePanelGroup } from '@/components/ui/resizable';
import ClaudeChat from '@/components/ClaudeChat';
import MonacoEditor from '@/components/MonacoEditor';
import PreviewFrame from '@/components/PreviewFrame';
import { Code, Eye, MessageSquare } from 'lucide-react';

const defaultCode = `function App() {
  const [count, setCount] = React.useState(0);

  return (
    <div style={{
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      fontFamily: 'system-ui, -apple-system, sans-serif',
      padding: '20px'
    }}>
      <div style={{
        background: 'white',
        borderRadius: '20px',
        padding: '40px',
        boxShadow: '0 20px 60px rgba(0,0,0,0.3)',
        textAlign: 'center',
        maxWidth: '500px',
        width: '100%'
      }}>
        <h1 style={{
          fontSize: '48px',
          background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
          WebkitBackgroundClip: 'text',
          WebkitTextFillColor: 'transparent',
          marginBottom: '20px',
          fontWeight: 'bold'
        }}>
          ✨ Sparky
        </h1>
        <p style={{
          color: '#666',
          fontSize: '18px',
          marginBottom: '30px'
        }}>
          AI-Powered Code Generator
        </p>
        <div style={{
          background: '#f7fafc',
          borderRadius: '15px',
          padding: '30px',
          marginBottom: '20px'
        }}>
          <p style={{
            fontSize: '72px',
            fontWeight: 'bold',
            color: '#667eea',
            margin: '0 0 10px 0'
          }}>
            {count}
          </p>
          <p style={{ color: '#888', fontSize: '14px' }}>Click the button below</p>
        </div>
        <button
          onClick={() => setCount(count + 1)}
          style={{
            background: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
            color: 'white',
            border: 'none',
            padding: '15px 40px',
            fontSize: '18px',
            borderRadius: '30px',
            cursor: 'pointer',
            fontWeight: '600',
            boxShadow: '0 4px 15px rgba(102, 126, 234, 0.4)',
            transition: 'all 0.3s ease',
            width: '100%'
          }}
          onMouseOver={(e) => {
            e.target.style.transform = 'translateY(-2px)';
            e.target.style.boxShadow = '0 6px 20px rgba(102, 126, 234, 0.6)';
          }}
          onMouseOut={(e) => {
            e.target.style.transform = 'translateY(0)';
            e.target.style.boxShadow = '0 4px 15px rgba(102, 126, 234, 0.4)';
          }}
        >
          Increment Counter
        </button>
      </div>
      <p style={{
        color: 'white',
        marginTop: '30px',
        fontSize: '14px',
        opacity: 0.9
      }}>
        Try asking the AI to modify this component! 🚀
      </p>
    </div>
  );
}`;

export default function Home() {
  const [code, setCode] = useState(defaultCode);

  const handleCodeGenerated = (newCode) => {
    setCode(newCode);
  };

  const handleCodeChange = (newCode) => {
    setCode(newCode);
  };

  return (
    <div className="h-screen flex flex-col overflow-hidden">
      {/* Header */}
      <header className="h-14 border-b flex items-center px-6 bg-gradient-to-r from-purple-600 to-pink-600 text-white flex-shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 bg-white rounded-lg flex items-center justify-center">
            <span className="text-2xl">✨</span>
          </div>
          <h1 className="text-xl font-bold">Sparky</h1>
        </div>
        <div className="ml-auto text-sm opacity-90">
          AI-Powered React Code Generator
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        <ResizablePanelGroup direction="horizontal" className="h-full">
          {/* Chat Panel */}
          <ResizablePanel defaultSize={30} minSize={20} maxSize={50}>
            <div className="h-full flex flex-col">
              <div className="h-10 border-b flex items-center px-4 bg-muted/50">
                <MessageSquare className="h-4 w-4 mr-2 text-purple-600" />
                <span className="text-sm font-medium">AI Chat</span>
              </div>
              <div className="flex-1 overflow-hidden">
                <ClaudeChat 
                  onCodeGenerated={handleCodeGenerated} 
                  currentCode={code}
                />
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Editor Panel */}
          <ResizablePanel defaultSize={35} minSize={25}>
            <div className="h-full flex flex-col">
              <div className="h-10 border-b flex items-center px-4 bg-muted/50">
                <Code className="h-4 w-4 mr-2 text-purple-600" />
                <span className="text-sm font-medium">Code Editor</span>
              </div>
              <div className="flex-1 overflow-hidden">
                <MonacoEditor 
                  value={code} 
                  onChange={handleCodeChange}
                  language="javascript"
                />
              </div>
            </div>
          </ResizablePanel>

          <ResizableHandle withHandle />

          {/* Preview Panel */}
          <ResizablePanel defaultSize={35} minSize={25}>
            <div className="h-full flex flex-col">
              <div className="h-10 border-b flex items-center px-4 bg-muted/50">
                <Eye className="h-4 w-4 mr-2 text-purple-600" />
                <span className="text-sm font-medium">Live Preview</span>
              </div>
              <div className="flex-1 overflow-hidden">
                <PreviewFrame code={code} />
              </div>
            </div>
          </ResizablePanel>
        </ResizablePanelGroup>
      </div>
    </div>
  );
}
