'use client';

import { useRef } from 'react';
import Editor from '@monaco-editor/react';
import { Loader2 } from 'lucide-react';
import { useTheme } from 'next-themes';

export default function MonacoEditor({ value, onChange, language = 'javascript' }) {
  const editorRef = useRef(null);
  const { theme } = useTheme();

  function handleEditorDidMount(editor, monaco) {
    editorRef.current = editor;

    // Configure Monaco for React/JSX
    monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
      target: monaco.languages.typescript.ScriptTarget.Latest,
      allowNonTsExtensions: true,
      moduleResolution: monaco.languages.typescript.ModuleResolutionKind.NodeJs,
      module: monaco.languages.typescript.ModuleKind.CommonJS,
      noEmit: true,
      esModuleInterop: true,
      jsx: monaco.languages.typescript.JsxEmit.React,
      reactNamespace: 'React',
      allowJs: true,
      typeRoots: ['node_modules/@types']
    });

    // Add React types
    monaco.languages.typescript.javascriptDefaults.setDiagnosticsOptions({
      noSemanticValidation: false,
      noSyntaxValidation: false
    });
  }

  function handleEditorChange(value) {
    if (onChange) {
      onChange(value);
    }
  }

  return (
    <div className="relative w-full h-full">
      <Editor
        height="100%"
        defaultLanguage={language}
        language={language}
        value={value}
        onChange={handleEditorChange}
        onMount={handleEditorDidMount}
        theme={theme === 'dark' ? 'vs-dark' : 'light'}
        options={{
          automaticLayout: true,
          minimap: { enabled: false },
          fontSize: 14,
          lineNumbers: 'on',
          roundedSelection: false,
          scrollBeyondLastLine: false,
          readOnly: false,
          cursorStyle: 'line',
          wordWrap: 'on',
          tabSize: 2,
          insertSpaces: true,
          folding: true,
          bracketPairColorization: {
            enabled: true
          },
          suggest: {
            showKeywords: true
          },
          padding: {
            top: 16,
            bottom: 16
          }
        }}
        loading={
          <div className="absolute inset-0 flex items-center justify-center bg-background">
            <div className="flex flex-col items-center gap-2">
              <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
              <p className="text-sm text-muted-foreground">Loading editor...</p>
            </div>
          </div>
        }
      />
    </div>
  );
}