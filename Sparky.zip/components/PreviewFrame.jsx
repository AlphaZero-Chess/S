'use client';

import { useEffect, useRef, useState } from 'react';
import { AlertCircle, Loader2 } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

export default function PreviewFrame({ code }) {
  const iframeRef = useRef(null);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!code) return;

    setIsLoading(true);
    setError(null);

    const renderPreview = () => {
      try {
        // Create preview HTML with inline transformation
        const previewHTML = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script crossorigin src="https://unpkg.com/react@18/umd/react.production.min.js"></script>
  <script crossorigin src="https://unpkg.com/react-dom@18/umd/react-dom.production.min.js"></script>
  <script src="https://unpkg.com/@babel/standalone@7.23.5/babel.min.js"></script>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, sans-serif;
    }
    #root {
      width: 100%;
      min-height: 100vh;
    }
    * {
      box-sizing: border-box;
    }
  </style>
</head>
<body>
  <div id="root"></div>
  <script type="text/babel" data-type="module">
    const { useState, useEffect, useRef, useCallback, useMemo } = React;
    
    ${code}
    
    const root = ReactDOM.createRoot(document.getElementById('root'));
    root.render(<App />);
  </script>
  <script>
    window.addEventListener('error', function(e) {
      document.body.innerHTML = '<div style="padding: 20px; color: red; font-family: monospace; background: #fff3f3; border: 2px solid red; margin: 20px; border-radius: 8px;"><h3 style="margin-top: 0;">Runtime Error:</h3><pre style="white-space: pre-wrap; word-wrap: break-word;">' + e.message + '\n\n' + (e.error ? e.error.stack : '') + '</pre></div>';
      window.parent.postMessage({ type: 'error', error: e.message }, '*');
    });
  </script>
</body>
</html>`;

        // Update iframe
        if (iframeRef.current) {
          iframeRef.current.srcdoc = previewHTML;
          
          // Set a timeout to hide loading state
          setTimeout(() => {
            setIsLoading(false);
          }, 1500);
        }
      } catch (err) {
        setError(`Error: ${err.message}`);
        setIsLoading(false);
      }
    };

    renderPreview();
  }, [code]);

  // Listen for errors from iframe
  useEffect(() => {
    const handleMessage = (event) => {
      if (event.data.type === 'error') {
        setError(event.data.error);
        setIsLoading(false);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, []);

  return (
    <div className="w-full h-full relative bg-white">
      {isLoading && (
        <div className="absolute inset-0 flex items-center justify-center bg-background z-10">
          <div className="flex flex-col items-center gap-2">
            <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
            <p className="text-sm text-muted-foreground">Rendering preview...</p>
          </div>
        </div>
      )}
      {error && (
        <div className="absolute top-4 left-4 right-4 z-20">
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription className="text-xs font-mono">{error}</AlertDescription>
          </Alert>
        </div>
      )}
      <iframe
        ref={iframeRef}
        className="w-full h-full border-0"
        sandbox="allow-scripts"
        title="Preview"
      />
    </div>
  );
}