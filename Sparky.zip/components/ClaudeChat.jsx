'use client';

import { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Textarea } from '@/components/ui/textarea';
import { Sparkles, Send, User, Copy, Check, Code } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function ClaudeChat({ onCodeGenerated, currentCode }) {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: "👋 Hi! I'm your AI coding assistant. I can help you:\n\n• Generate React components\n• Modify existing code\n• Add new features\n• Fix bugs\n• Explain code patterns\n\nTry asking me to create or modify components!"
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [streamingMessage, setStreamingMessage] = useState('');
  const [copiedIndex, setCopiedIndex] = useState(null);
  const messagesEndRef = useRef(null);
  const scrollAreaRef = useRef(null);

  // Auto-scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, streamingMessage]);

  const extractCodeFromResponse = (text) => {
    // Extract code blocks from markdown
    const codeBlockRegex = /```(?:jsx?|javascript|typescript)?\n([\s\S]*?)```/g;
    const matches = [...text.matchAll(codeBlockRegex)];
    
    if (matches.length > 0) {
      // Return the last code block (usually the complete component)
      return matches[matches.length - 1][1].trim();
    }
    
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage = { role: 'user', content: input };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setStreamingMessage('');

    try {
      // Build context-aware prompt
      const contextPrompt = currentCode 
        ? `Current code:\n\`\`\`javascript\n${currentCode}\n\`\`\`\n\n${input}`
        : input;

      const systemMessage = {
        role: 'system',
        content: 'You are a expert React developer assistant. Generate clean, modern React code using functional components and hooks. Always wrap your code in ```jsx or ```javascript code blocks. Focus on creating beautiful, responsive UIs with inline styles or Tailwind classes. Keep responses concise but informative.'
      };

      // Format messages for Claude API
      const formattedMessages = messages
        .filter(msg => msg.role !== 'system')
        .concat(userMessage)
        .map(msg => ({
          role: msg.role === 'assistant' ? 'assistant' : 'user',
          content: msg.content
        }));

      // Add context to the last user message
      if (formattedMessages.length > 0) {
        formattedMessages[formattedMessages.length - 1].content = contextPrompt;
      }

      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          messages: formattedMessages,
          systemPrompt: systemMessage.content
        }),
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const reader = response.body.getReader();
      const decoder = new TextDecoder();
      let done = false;
      let accumulatedMessage = '';

      while (!done) {
        const { value, done: doneReading } = await reader.read();
        done = doneReading;
        
        if (value) {
          const chunk = decoder.decode(value, { stream: true });
          accumulatedMessage += chunk;
          setStreamingMessage(accumulatedMessage);
        }
      }

      // Check if response contains code and update editor
      const extractedCode = extractCodeFromResponse(accumulatedMessage);
      if (extractedCode && onCodeGenerated) {
        onCodeGenerated(extractedCode);
      }

      setMessages((prev) => [
        ...prev,
        { role: 'assistant', content: accumulatedMessage }
      ]);
    } catch (error) {
      console.error('Error:', error);
      setMessages((prev) => [
        ...prev,
        { 
          role: 'assistant', 
          content: '❌ Sorry, there was an error processing your request. Please try again.' 
        }
      ]);
    } finally {
      setIsLoading(false);
      setStreamingMessage('');
    }
  };

  const handleCopyCode = (content, index) => {
    const code = extractCodeFromResponse(content);
    if (code) {
      navigator.clipboard.writeText(code);
      setCopiedIndex(index);
      setTimeout(() => setCopiedIndex(null), 2000);
    }
  };

  const renderMessage = (message, index) => {
    const isUser = message.role === 'user';
    const hasCode = message.content.includes('```');

    return (
      <div
        key={index}
        className={cn(
          'flex gap-3 p-4 rounded-lg',
          isUser ? 'bg-purple-50 dark:bg-purple-950/20' : 'bg-muted/50'
        )}
      >
        <div className={cn(
          'w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0',
          isUser ? 'bg-purple-600' : 'bg-gradient-to-br from-purple-600 to-pink-600'
        )}>
          {isUser ? (
            <User className="w-4 h-4 text-white" />
          ) : (
            <Sparkles className="w-4 h-4 text-white" />
          )}
        </div>
        <div className="flex-1 space-y-2 overflow-hidden">
          <div className="prose prose-sm dark:prose-invert max-w-none">
            {message.content.split('```').map((part, i) => {
              if (i % 2 === 0) {
                return (
                  <div key={i} className="whitespace-pre-wrap break-words">
                    {part}
                  </div>
                );
              } else {
                const [lang, ...code] = part.split('\n');
                return (
                  <div key={i} className="relative group my-3">
                    <div className="absolute right-2 top-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Button
                        size="sm"
                        variant="secondary"
                        onClick={() => handleCopyCode(message.content, index)}
                        className="h-7 text-xs"
                      >
                        {copiedIndex === index ? (
                          <><Check className="w-3 h-3 mr-1" /> Copied</>
                        ) : (
                          <><Copy className="w-3 h-3 mr-1" /> Copy</>
                        )}
                      </Button>
                    </div>
                    <pre className="bg-slate-900 text-slate-100 p-4 rounded-lg overflow-x-auto text-sm">
                      <code>{code.join('\n').trim()}</code>
                    </pre>
                  </div>
                );
              }
            })}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="h-10 border-b flex items-center px-4 bg-muted/50">
        <Sparkles className="h-4 w-4 mr-2 text-purple-600" />
        <span className="text-sm font-medium">AI Assistant</span>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-4">
          {messages.map((message, index) => renderMessage(message, index))}
          {streamingMessage && (
            <div className="flex gap-3 p-4 rounded-lg bg-muted/50">
              <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 bg-gradient-to-br from-purple-600 to-pink-600">
                <Sparkles className="w-4 h-4 text-white" />
              </div>
              <div className="flex-1 space-y-2 overflow-hidden">
                <div className="prose prose-sm dark:prose-invert max-w-none">
                  <div className="whitespace-pre-wrap break-words">
                    {streamingMessage}
                    <span className="inline-block w-2 h-4 ml-1 bg-purple-600 animate-pulse" />
                  </div>
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      {/* Input */}
      <div className="border-t p-4 bg-card">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask me to build or modify components..."
            className="resize-none min-h-[60px] max-h-[120px]"
            disabled={isLoading}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSubmit(e);
              }
            }}
          />
          <Button
            type="submit"
            size="icon"
            disabled={isLoading || !input.trim()}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 self-end"
          >
            <Send className="h-4 w-4" />
          </Button>
        </form>
        <p className="text-xs text-muted-foreground mt-2">
          Press Enter to send, Shift+Enter for new line
        </p>
      </div>
    </div>
  );
}