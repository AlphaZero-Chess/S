from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
from emergentintegrations.llm.chat import LlmChat, UserMessage
import os
import asyncio
import threading
from queue import Queue
import time

app = Flask(__name__)
CORS(app)

# Get API key from environment
EMERGENT_LLM_KEY = os.getenv('EMERGENT_LLM_KEY', 'sk-emergent-bD7C6120fDaA500472')

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "service": "claude-ai-streaming"})

def create_claude_client(session_id=None):
    """Create a Claude client with Emergent LLM Key"""
    if not session_id:
        session_id = f"session-{int(time.time())}"
    
    # Use Claude 3.7 Sonnet (Claude 4.5)
    chat = LlmChat(
        api_key=EMERGENT_LLM_KEY,
        session_id=session_id,
        system_message="You are an expert React developer assistant."
    ).with_model("anthropic", "claude-3-7-sonnet-20250219")
    
    return chat

@app.route('/chat', methods=['POST'])
def chat():
    """Non-streaming chat endpoint (fallback)"""
    try:
        data = request.json
        messages = data.get('messages', [])
        session_id = data.get('sessionId')
        system_prompt = data.get('systemPrompt', '')
        
        if not messages:
            return jsonify({"error": "Messages are required"}), 400
        
        # Get the last user message
        last_message = messages[-1] if messages else None
        if not last_message or last_message.get('role') != 'user':
            return jsonify({"error": "Last message must be from user"}), 400
        
        # Create chat client
        chat = create_claude_client(session_id)
        if system_prompt:
            chat.system_message = system_prompt
        
        # Build context from previous messages
        conversation_context = ""
        for msg in messages[:-1]:
            role = msg.get('role', '')
            content = msg.get('content', '')
            if role == 'user':
                conversation_context += f"User: {content}\n"
            elif role == 'assistant':
                conversation_context += f"Assistant: {content}\n"
        
        # Create user message with context
        full_message = conversation_context + last_message.get('content', '')
        user_message = UserMessage(text=full_message)
        
        # Send message in async context
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            response = loop.run_until_complete(chat.send_message(user_message))
        finally:
            loop.close()
        
        # Extract text from response
        response_text = ""
        if hasattr(response, 'text'):
            response_text = response.text
        elif hasattr(response, 'content'):
            if isinstance(response.content, list):
                for block in response.content:
                    if hasattr(block, 'text'):
                        response_text += block.text
            else:
                response_text = str(response.content)
        else:
            response_text = str(response)
        
        return jsonify({
            "success": True,
            "text": response_text,
            "sessionId": chat.session_id
        })
        
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/chat/stream', methods=['POST'])
def chat_stream():
    """
    Simulated streaming chat endpoint.
    
    Note: emergentintegrations doesn't support true token-level streaming yet,
    so we fetch the complete response and stream it word-by-word for better UX.
    """
    try:
        data = request.json
        messages = data.get('messages', [])
        session_id = data.get('sessionId')
        system_prompt = data.get('systemPrompt', '')
        
        if not messages:
            return jsonify({"error": "Messages are required"}), 400
        
        # Get the last user message
        last_message = messages[-1] if messages else None
        if not last_message or last_message.get('role') != 'user':
            return jsonify({"error": "Last message must be from user"}), 400
        
        def generate():
            """Generator function for streaming response"""
            try:
                # Create chat client
                chat = create_claude_client(session_id)
                if system_prompt:
                    chat.system_message = system_prompt
                
                # Build context from previous messages
                conversation_context = ""
                for msg in messages[:-1]:
                    role = msg.get('role', '')
                    content = msg.get('content', '')
                    if role == 'user':
                        conversation_context += f"User: {content}\n"
                    elif role == 'assistant':
                        conversation_context += f"Assistant: {content}\n"
                
                # Create user message with context
                full_message = conversation_context + last_message.get('content', '')
                user_message = UserMessage(text=full_message)
                
                # Send message in async context
                loop = asyncio.new_event_loop()
                asyncio.set_event_loop(loop)
                try:
                    response = loop.run_until_complete(chat.send_message(user_message))
                finally:
                    loop.close()
                
                # Extract text from response
                response_text = ""
                if hasattr(response, 'text'):
                    response_text = response.text
                elif hasattr(response, 'content'):
                    if isinstance(response.content, list):
                        for block in response.content:
                            if hasattr(block, 'text'):
                                response_text += block.text
                    else:
                        response_text = str(response.content)
                else:
                    response_text = str(response)
                
                # Stream the response word-by-word for better UX
                words = response_text.split(' ')
                for i, word in enumerate(words):
                    if i < len(words) - 1:
                        yield word + ' '
                    else:
                        yield word
                    # Small delay for smoother streaming effect
                    time.sleep(0.02)
                    
            except Exception as e:
                import traceback
                error_msg = f"\n\nError: {str(e)}\n{traceback.format_exc()}"
                print(error_msg)
                yield f"❌ Error generating response. Please try again."
        
        # Return streaming response
        return Response(
            stream_with_context(generate()),
            mimetype='text/plain',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive'
            }
        )
        
    except Exception as e:
        print(f"Error in streaming endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.getenv('PYTHON_SERVICE_PORT', 5000))
    print(f"🚀 Starting Claude AI Service (Claude 3.7 Sonnet)")
    print(f"   Port: {port}")
    print(f"   Model: claude-3-7-sonnet-20250219 (Claude 4.5)")
    print(f"   Streaming: ✅ Word-by-word (simulated)")
    print(f"   Note: Using Emergent LLM Key integration")
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
