from flask import Flask, request, jsonify, Response
from flask_cors import CORS
from emergentintegrations.llm.chat import LlmChat, UserMessage
import os
import json

app = Flask(__name__)
CORS(app)  # Enable CORS for Next.js to call this service

# Store chat sessions in memory (in production, use Redis or database)
sessions = {}

def create_claude_client(session_id=None):
    """Create a Claude client with Emergent LLM Key"""
    api_key = os.getenv('EMERGENT_LLM_KEY', 'sk-emergent-bD7C6120fDaA500472')
    
    if not session_id:
        session_id = f"session-{len(sessions)}"
    
    # Use Claude 3.7 Sonnet (latest available model)
    chat = LlmChat(
        api_key=api_key,
        session_id=session_id,
        system_message="You are an expert React developer assistant. Generate clean, modern React code using functional components and hooks. CRITICAL: Always name the main component 'App' (function App() {...}) and ensure it works standalone. Always wrap your code in ```jsx or ```javascript code blocks. Focus on creating beautiful, responsive UIs with inline styles. Only output the complete, runnable component code in a single code block."
    ).with_model("anthropic", "claude-3-7-sonnet-20250219")
    
    return chat

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "service": "claude-ai"})

@app.route('/chat', methods=['POST'])
def chat():
    """Chat endpoint with streaming support"""
    import asyncio
    try:
        data = request.json
        messages = data.get('messages', [])
        session_id = data.get('sessionId')
        
        if not messages:
            return jsonify({"error": "Messages are required"}), 400
        
        # Get the last user message
        last_message = messages[-1] if messages else None
        if not last_message or last_message.get('role') != 'user':
            return jsonify({"error": "Last message must be from user"}), 400
        
        # Create or get chat client
        chat = create_claude_client(session_id)
        
        # Build context from previous messages
        conversation_context = ""
        for msg in messages[:-1]:
            role = msg.get('role', '')
            content = msg.get('content', '')
            if role == 'user':
                conversation_context += f"User: {content}\n"
            elif role == 'assistant':
                conversation_context += f"Assistant: {content}\n"
        
        # Create user message with context
        full_message = conversation_context + last_message.get('content', '')
        user_message = UserMessage(text=full_message)
        
        # Send message and get response (handle async if needed)
        response = chat.send_message(user_message)
        
        # If response is a coroutine, await it
        if asyncio.iscoroutine(response):
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            response = loop.run_until_complete(response)
            loop.close()
        
        # Extract text from response
        response_text = ""
        if hasattr(response, 'text'):
            response_text = response.text
        elif hasattr(response, 'content'):
            if isinstance(response.content, list):
                for block in response.content:
                    if hasattr(block, 'text'):
                        response_text += block.text
            else:
                response_text = str(response.content)
        else:
            response_text = str(response)
        
        return jsonify({
            "success": True,
            "text": response_text,
            "sessionId": chat.session_id
        })
        
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/chat/stream', methods=['POST'])
def chat_stream():
    """Streaming chat endpoint"""
    import asyncio
    try:
        data = request.json
        messages = data.get('messages', [])
        session_id = data.get('sessionId')
        
        if not messages:
            return jsonify({"error": "Messages are required"}), 400
        
        # Get the last user message
        last_message = messages[-1] if messages else None
        if not last_message or last_message.get('role') != 'user':
            return jsonify({"error": "Last message must be from user"}), 400
        
        def generate():
            try:
                # Create or get chat client
                chat = create_claude_client(session_id)
                
                # Build context from previous messages
                conversation_context = ""
                for msg in messages[:-1]:
                    role = msg.get('role', '')
                    content = msg.get('content', '')
                    if role == 'user':
                        conversation_context += f"User: {content}\n"
                    elif role == 'assistant':
                        conversation_context += f"Assistant: {content}\n"
                
                # Create user message with context
                full_message = conversation_context + last_message.get('content', '')
                user_message = UserMessage(text=full_message)
                
                # Send message and get response
                response = chat.send_message(user_message)
                
                # If response is a coroutine, await it
                if asyncio.iscoroutine(response):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    response = loop.run_until_complete(response)
                    loop.close()
                
                # Extract and yield text
                response_text = ""
                if hasattr(response, 'text'):
                    response_text = response.text
                elif hasattr(response, 'content'):
                    if isinstance(response.content, list):
                        for block in response.content:
                            if hasattr(block, 'text'):
                                response_text += block.text
                    else:
                        response_text = str(response.content)
                else:
                    response_text = str(response)
                
                # Stream the response in chunks
                chunk_size = 50
                for i in range(0, len(response_text), chunk_size):
                    chunk = response_text[i:i+chunk_size]
                    yield chunk
                    
            except Exception as e:
                import traceback
                error_msg = f"Error: {str(e)}\n{traceback.format_exc()}"
                print(error_msg)
                yield error_msg
        
        return Response(generate(), mimetype='text/plain')
        
    except Exception as e:
        print(f"Error in streaming endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.getenv('PYTHON_SERVICE_PORT', 5000))
    print(f"Starting Claude AI service on port {port}...")
    app.run(host='0.0.0.0', port=port, debug=False)