from flask import Flask, request, jsonify, Response, stream_with_context
from flask_cors import CORS
import anthropic
import os
import json

app = Flask(__name__)
CORS(app)

# Get API key from environment
EMERGENT_LLM_KEY = os.getenv('EMERGENT_LLM_KEY', 'sk-emergent-bD7C6120fDaA500472')

# Initialize Anthropic client
client = anthropic.Anthropic(api_key=EMERGENT_LLM_KEY)

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint"""
    return jsonify({"status": "healthy", "service": "claude-ai-streaming"})

@app.route('/chat', methods=['POST'])
def chat():
    """Non-streaming chat endpoint (fallback)"""
    try:
        data = request.json
        messages = data.get('messages', [])
        system_prompt = data.get('systemPrompt', '')
        
        if not messages:
            return jsonify({"error": "Messages are required"}), 400
        
        # Format messages for Anthropic API
        formatted_messages = []
        for msg in messages:
            role = msg.get('role', '')
            content = msg.get('content', '')
            
            # Anthropic API only accepts 'user' and 'assistant' roles
            if role in ['user', 'assistant']:
                formatted_messages.append({
                    "role": role,
                    "content": content
                })
        
        # Create message with Anthropic API
        response = client.messages.create(
            model="claude-3-5-sonnet-20241022",  # Claude 4.5 Sonnet
            max_tokens=8000,
            system=system_prompt if system_prompt else "You are an expert React developer assistant.",
            messages=formatted_messages,
            temperature=0.7
        )
        
        # Extract text from response
        response_text = ""
        if hasattr(response, 'content') and len(response.content) > 0:
            response_text = response.content[0].text
        
        return jsonify({
            "success": True,
            "text": response_text,
            "model": response.model,
            "usage": {
                "input_tokens": response.usage.input_tokens,
                "output_tokens": response.usage.output_tokens
            }
        })
        
    except Exception as e:
        print(f"Error in chat endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({
            "success": False,
            "error": str(e)
        }), 500

@app.route('/chat/stream', methods=['POST'])
def chat_stream():
    """TRUE streaming chat endpoint with token-by-token delivery"""
    try:
        data = request.json
        messages = data.get('messages', [])
        system_prompt = data.get('systemPrompt', '')
        
        if not messages:
            return jsonify({"error": "Messages are required"}), 400
        
        # Format messages for Anthropic API
        formatted_messages = []
        for msg in messages:
            role = msg.get('role', '')
            content = msg.get('content', '')
            
            # Anthropic API only accepts 'user' and 'assistant' roles
            if role in ['user', 'assistant']:
                formatted_messages.append({
                    "role": role,
                    "content": content
                })
        
        def generate():
            """Generator function for streaming response"""
            try:
                # Create streaming message with Anthropic API
                with client.messages.stream(
                    model="claude-3-5-sonnet-20241022",  # Claude 4.5 Sonnet
                    max_tokens=8000,
                    system=system_prompt if system_prompt else "You are an expert React developer assistant.",
                    messages=formatted_messages,
                    temperature=0.7
                ) as stream:
                    # Stream each text delta as it arrives
                    for text in stream.text_stream:
                        # Yield each token immediately
                        yield text
                        
            except Exception as e:
                import traceback
                error_msg = f"\n\nError: {str(e)}\n{traceback.format_exc()}"
                print(error_msg)
                yield error_msg
        
        # Return streaming response
        return Response(
            stream_with_context(generate()),
            mimetype='text/plain',
            headers={
                'Cache-Control': 'no-cache',
                'X-Accel-Buffering': 'no',
                'Connection': 'keep-alive'
            }
        )
        
    except Exception as e:
        print(f"Error in streaming endpoint: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    port = int(os.getenv('PYTHON_SERVICE_PORT', 5000))
    print(f"🚀 Starting Claude AI Streaming Service (Claude 4.5 Sonnet)")
    print(f"   Port: {port}")
    print(f"   Model: claude-3-5-sonnet-20241022")
    print(f"   Streaming: ✅ Token-by-token")
    app.run(host='0.0.0.0', port=port, debug=False, threaded=True)
