#!/bin/bash
export EMERGENT_LLM_KEY=sk-emergent-b3aD3A51f77Df40AfE
export PYTHON_SERVICE_PORT=5000
python3 claude_service.py