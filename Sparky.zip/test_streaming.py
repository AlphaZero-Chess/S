#!/usr/bin/env python3
"""Test script to verify Claude streaming functionality"""
import requests
import time
import json

def test_health():
    """Test health endpoint"""
    print("🔍 Testing health endpoint...")
    response = requests.get("http://localhost:5000/health")
    if response.status_code == 200:
        print(f"✅ Health check passed: {response.json()}")
        return True
    else:
        print(f"❌ Health check failed: {response.status_code}")
        return False

def test_streaming():
    """Test streaming chat endpoint"""
    print("\n🔍 Testing streaming endpoint...")
    print("Sending request: 'Create a simple button component'")
    
    url = "http://localhost:5000/chat/stream"
    payload = {
        "messages": [
            {"role": "user", "content": "Create a simple React button component in 3 lines"}
        ],
        "systemPrompt": "You are a React expert. Be concise."
    }
    
    try:
        start_time = time.time()
        response = requests.post(url, json=payload, stream=True, timeout=30)
        
        if response.status_code != 200:
            print(f"❌ Request failed with status {response.status_code}")
            print(f"Response: {response.text}")
            return False
        
        print("✅ Streaming started...")
        print("📝 Response (streaming):\n")
        
        chunk_count = 0
        first_chunk_time = None
        total_text = ""
        
        for chunk in response.iter_content(chunk_size=None, decode_unicode=True):
            if chunk:
                chunk_count += 1
                if first_chunk_time is None:
                    first_chunk_time = time.time()
                    ttfb = first_chunk_time - start_time
                    print(f"\n⏱️  Time to first byte: {ttfb:.3f}s")
                    print("─" * 60)
                
                print(chunk, end='', flush=True)
                total_text += chunk
        
        end_time = time.time()
        total_time = end_time - start_time
        
        print("\n" + "─" * 60)
        print(f"\n✅ Streaming completed!")
        print(f"📊 Stats:")
        print(f"   - Total chunks: {chunk_count}")
        print(f"   - Total time: {total_time:.3f}s")
        print(f"   - Response length: {len(total_text)} characters")
        print(f"   - Streaming speed: {len(total_text)/total_time:.1f} chars/sec")
        
        return chunk_count > 5  # Should receive multiple chunks
        
    except Exception as e:
        print(f"❌ Error during streaming test: {str(e)}")
        import traceback
        traceback.print_exc()
        return False

def test_nextjs_api():
    """Test Next.js API route"""
    print("\n🔍 Testing Next.js API route...")
    
    url = "http://localhost:3000/api/chat"
    payload = {
        "messages": [
            {"role": "user", "content": "Say hello in 3 words"}
        ],
        "systemPrompt": "Be brief."
    }
    
    try:
        start_time = time.time()
        response = requests.post(url, json=payload, stream=True, timeout=30)
        
        if response.status_code != 200:
            print(f"❌ Request failed with status {response.status_code}")
            return False
        
        print("✅ Next.js API streaming started...")
        print("📝 Response:\n")
        
        chunk_count = 0
        for chunk in response.iter_content(chunk_size=None, decode_unicode=True):
            if chunk:
                chunk_count += 1
                print(chunk, end='', flush=True)
        
        end_time = time.time()
        print(f"\n\n✅ Next.js API test completed in {end_time - start_time:.3f}s")
        print(f"   - Chunks received: {chunk_count}")
        
        return chunk_count > 5
        
    except Exception as e:
        print(f"❌ Error during Next.js API test: {str(e)}")
        return False

def main():
    """Run all tests"""
    print("=" * 60)
    print("🚀 Sparky Streaming Tests")
    print("=" * 60)
    
    results = {
        "health": test_health(),
        "streaming": test_streaming(),
        "nextjs_api": test_nextjs_api()
    }
    
    print("\n" + "=" * 60)
    print("📊 Test Results Summary")
    print("=" * 60)
    
    for test_name, passed in results.items():
        status = "✅ PASSED" if passed else "❌ FAILED"
        print(f"{test_name.upper()}: {status}")
    
    all_passed = all(results.values())
    print("\n" + "=" * 60)
    if all_passed:
        print("🎉 All tests passed! Streaming is working correctly.")
    else:
        print("⚠️  Some tests failed. Please review the output above.")
    print("=" * 60)
    
    return 0 if all_passed else 1

if __name__ == "__main__":
    exit(main())
